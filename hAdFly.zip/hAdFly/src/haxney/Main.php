<?php

namespace haxney;

use pocketmine\plugin\PluginBase;
use pocketmine\item\Item;
use haxney\item\Botas;
use haxney\item\Peitoral;
use haxney\events\EventListener;

use function compact;

class Main extends PluginBase {

 /** @var PluginBase $instance **/
 private static $instance = \null;

 public function onLoad() {
  self::$instance = $this;
 }

 public function onEnable() {
  $pl = '§bMy (plugin) Name Is: hAdFly';
  $author = '§aMy author Is Called: Haxney_ or Haxney1319';
  $version = 'My (Plugin)version Is: Currently 1.0';
  $info = compact('pl', 'author', 'version');

  array_walk($info, function(string $info) {
   $this->getLogger()->info($info);
  });

  Peitoral::$list[Peitoral::ID] = Peitoral::class;


  Item::addCreativeItem(Item::get(1888)->setCustomName('§r§bPeitoral Divino'));

  new EventListener();
 }

 /** @return PluginBase **/
 public static function getInstance() : PluginBase {
  return self::$instance;
 }
}