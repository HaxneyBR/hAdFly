<?php

namespace haxney\events;

use pocketmine\Player;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityArmorChangeEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\item\Item;
use haxney\Main;

class EventListener implements Listener {

 /**
 * EventListener constructor.
 **/
 public function __construct() {
  $instance = Main::getInstance();

  $instance->getServer()->getPluginManager()->registerEvents($this, $instance);
 }

 /**
 * @param EntityArmorChangeEvent $event
 *
 * @priority HIGHEST
 * @return Void
 **/
 public function EntityArmorChangeEvent(EntityArmorChangeEvent $event) {
  $p = $event->getEntity();
  $oldItem = $event->getOldItem();
  $newItem = $event->getNewItem();

  if ($newItem->getId() === 303 && $newItem->getCustomName() === '§bPeitoral Divino') {
   $damage = $newItem->getDamage();
   $newItem->setDamage($damage + 200);

   $p->setAllowFlight(true);
  }

  if ($oldItem->getId() === 303 && $oldItem->getCustomName() === '§r§bPeitoral Divino') {
   $damage = $oldItem->getDamage();
   $oldItem->setDamage($damage + 200);

   $p->setAllowFlight(false);
  }
 }

 /**
 * @param PlayerMoveEvent $event
 *
 * @priority HIGHEST
 * @return Void
 **/
 public function PlayerMoveEvent(PlayerMoveEvent $event) {
  $p = $event->getPlayer();
  $item = $p->getInventory()->getChestplate();

  if ($item->getId() === 303 && $item->getCustomName() === '§r§bPeitoral Divino') {
   $damage = $item->getDamage();
   $item->setDamage($damage + 100);
  }
 }

 /**
 * @param PlayerChatEvent $event
 *
 * @priority MEDIUM
 * @return Void
 **/
 public function PlayerChatEvent(PlayerChatEvent $event) {
  $p = $event->getPlayer();
  $args = explode(' ', $event->getMessage());

  if ($args[0] === '@adfly') {
   if ($p->hasPermission('adfly.perm')) {

    $event->setCancelled(true);

    if (empty($args[1])) {
     $p->sendMessage('§eNotei que está perdido. Use @adfly help');
    } else {
     if (in_array($args[1], ['?', 'ajuda', 'help'])) {
      $event->setCancelled(true);

      $msg = [
       '§aLISTA DE COMANDOS',
       '§r',
       '§a@adfly give [player] [quantidade] - §7Use esse comando para dar um item arcanjo para um jogador especifico.'
      ];

      $p->sendMessage(implode(PHP_EOL, $msg));
     }

     if ($args[1] == 'give') {
      $event->setCancelled(true);

      if (empty($args[2]) or empty($args[3])) {
       $p->sendMessage('§cVocê precisa inserir o jogador e quantidade.');
      } else {
       $instance = Main::getInstance();

       $player = $instance->getServer()->getPlayer($args[2]);

       if ($player instanceof Player) {
        $count = $args[3];
        $inv = $player->getInventory();

        $item = Item::get(1888, 0, $count)->setCustomName('§r§bPeitoral Divino');
        $inv->addItem($item);
        $p->sendMessage(PHP_EOL.'§aO item foi dado com sucesso para §r§f'.$player->getName().PHP_EOL);
       }
      }
     }
    }
   } else {
    return true;
   }
  }
 }
}