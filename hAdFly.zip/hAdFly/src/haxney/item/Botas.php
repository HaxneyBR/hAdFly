<?php

namespace haxney\item;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\item\Item;

class Botas extends Item {

 const ID = 1889;
 const ITEM = 305;
 const NAME = 'Botas Divinas';

 /**
 * Botas constructor
 *
 * @param int $meta
 * @param int $count
 * @const NAME
 **/
 
 public function __construct(int $meta = 0, int $count = 1) {
  parent::__construct(self::ITEM, $meta, $count, self::NAME);
 }
 
 public function getMaxStackSize() : int {
     return 1;
     // this make that stack only one
 }
 
 public function getCustomName() : string {
     return "§bBotas Divinas";
     // show in display the name 
 }
}