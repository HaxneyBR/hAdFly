<?php

namespace haxney\item;

use pocketmine\Player;
use pocketmine\item\Item;

class Peitoral extends Item {

 const ID = 1888;
 const ITEM = 303;
 const NAME = 'Peitoral Divino';

 /**
 * BreastplateArchangel constructor.
 *
 * @param int $meta
 * @param int $count
 **/
 
 public function __construct(int $meta = 0, int $count = 1) {
  parent::__construct(self::ITEM, $meta, $count, self::NAME);
 }

 public function getMaxStackSize() : int {
  return 1;
 }

 public function getCustomName() : string {
  return '§bPeitoral Divino';
 }
}